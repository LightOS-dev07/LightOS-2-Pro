# LightOS 2 Pro — Complete Documentation

> A bare-metal x86 operating system built from scratch in C++ and Assembly.  
> No Linux. No POSIX. No standard library. Pure metal.

---

## Table of Contents

1. [What is LightOS?](#what-is-lightos)
2. [Building](#building)
3. [Running](#running)
4. [Applications](#applications)
5. [Keyboard Shortcuts](#keyboard-shortcuts)
6. [Developer Mode](#developer-mode)
7. [LightSurf Browser](#lightsurf-browser)
8. [Network Support](#network-support)
9. [Themes & Wallpapers](#themes--wallpapers)
10. [Architecture](#architecture)
11. [File System](#file-system)
12. [Contributing](#contributing)

---

## What is LightOS?

LightOS 2 Pro is a **32-bit protected mode** operating system written entirely in C++ and x86 Assembly. It boots via GRUB (Multiboot1), runs a custom GUI compositor, and includes real applications — no existing OS components are used.

**Key facts:**
- x86 Protected Mode + SSE2
- Custom GUI with window compositing, shadows, animations
- 9 built-in applications + 10 developer tools
- RAM-based virtual filesystem (VFS)
- ACPI shutdown/restart
- PS/2 keyboard & mouse
- RTL8139 network driver + TCP/IP stack
- PC Speaker + AC97 audio
- Boot animation + Developer Mode

---



### Build Output

```
[1/6] Apps...       notepad, calculator, filemgr, settings, terminal, paint, sysinfo, clock_app
[2/6] Drivers...    boot.asm (nasm), io, keyboard, mouse
[3/6] Kernel...     kernel/init.c
[4/6] Shell...      shell.cpp (GUI loop)
[5/6] Link...       kernel.bin (ELF → flat binary)
[6/6] ISO...        LightOS.iso (GRUB Multiboot1)
```

---

## Running

### VirtualBox (Recommended)

| Setting | Value |
|---------|-------|
| Type | Other / Unknown 32-bit |
| RAM | 256 MB |
| Graphics | VMSVGA, 64 MB VRAM |
| Audio | ICH AC97 + Windows DirectSound |
| Network | PCnet-PCI II (Am79C970A) |
| IO APIC | **Disabled** |
| Boot | CD/DVD → LightOS.iso |

### QEMU (with networking)

**Windows:**
```powershell
"C:\Program Files\qemu\qemu-system-x86_64.exe" -m 1G -cdrom C:\lightos_project\lightos.iso -boot d -accel whpx -display sd
```

**Linux:**
```bash
qemu-system-x86_64 -m 1G -cdrom ~/lightos_project/lightos.iso -boot d -accel kvm -display sdl
```

**macOS:**
```bash
qemu-system-x86_64 -m 1G -cdrom ~/lightos_project/lightos.iso -boot d -accel hvf -display sdl
```

### Real Hardware

1. Build `LightOS.iso`
2. Flash with **Rufus** (DD mode) to USB
3. Boot from USB (disable Secure Boot in BIOS)

---

## Applications

### Notepad
Text editor with VFS save support.
- **Save:** Click `Save` button or `Ctrl+S`
- **File:** Opens from File Manager (double-click `.txt`)
- Line numbers, scroll, modified indicator (`*` in title)

### File Manager
Full VFS browser.

| Action | How |
|--------|-----|
| Enter folder | Double-click |
| Go back | `Backspace` or `<-` button |
| New folder | `+ Folder` button |
| New file | `+ File` button |
| Delete | Select item → `Delete` button |
| Rename | Select item → press `R` |
| Open in Notepad | Double-click `.txt` file |

> System files (`System/`, `kernel.bin`) are hidden unless Developer Mode is active.

### Calculator
Basic arithmetic: `+` `−` `×` `÷`  
- Divide by zero protection
- Click digits once — no spam

### Settings
Three tabs:

| Tab | Options |
|-----|---------|
| Keyboard | TR-Q (Turkish) / EN-US layout |
| Theme | Luna Steel / ColdIceBar |
| Wallpaper | Luna Night / Dawn / Forest |

Changes apply immediately after clicking **Apply**.

### Terminal
Full command-line interface over VFS.

| Command | Description |
|---------|-------------|
| `ls [dir]` | List directory contents |
| `cd <dir>` | Change directory |
| `cd ..` | Go up one level |
| `cat <file>` | Print file contents |
| `echo <text>` | Print text |
| `mkdir <name>` | Create directory |
| `rm <name>` | Remove file or directory |
| `pwd` | Print working directory |
| `clear` | Clear screen |
| `ver` | Show OS version |
| `mem` | Show RAM info |
| `help` | List all commands |

- ↑ / ↓ arrows: command history

### Paint
Pixel art drawing tool.

| Tool | Description |
|------|-------------|
| Pen | Draw freehand |
| Eraser | Erase pixels |
| Fill | Flood fill area |
| Line | Draw straight line |

- 16-color palette
- Adjustable brush size (`-` / `+`)
- Canvas: 320×200 pixels

### Clock
Analog + digital clock using real RTC time.
- Hour, minute, second hands
- Digital display (2× scale, green LCD style)

### System Info
Real-time system information:
- RAM total (from BIOS/Multiboot)
- Display resolution + bpp
- Current time and date (RTC)
- VFS node count
- Developer Mode status

### LightSurf Browser
Built-in web browser — see [LightSurf Browser](#lightsurf-browser) section.

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+S` | Save file (Notepad) |
| `Ctrl+F` | Search in page (Browser) |
| `Ctrl+D` | Bookmark page (Browser) |
| `Ctrl+B` | Trigger BSOD *(Dev Mode only)* |
| `R` | Rename selected item (File Manager) |
| `Backspace` | Go up directory (File Manager) |
| `↑` / `↓` | Command history (Terminal) |
| `ESC` | Cancel search / close URL edit |
| `F4` ×5 | Activate Developer Mode (at boot) |

---

## Developer Mode

Developer Mode unlocks system internals and debug tools.

### Activating

During the **5-second boot animation**, press **F4 five times**.

A confirmation prompt appears:
```
! DEVELOPER MODE

Are you sure for opening DEVELOPER MODE?

   [Y] Yes         [N] No

Auto-cancel in: 10 seconds
```

- **Y** → Developer Mode activates, system continues normally
- **N** or timeout → Normal boot, nothing changes

### What it unlocks

- **File Manager:** System files visible (`System/`, `kernel.bin`, `boot.cfg`)
- **QuickMenu:** Developer Tools section appears
- **Desktop:** 10 dev tool icons on right side
- **Ctrl+B:** BSOD test trigger

### Developer Tools (10)

| Tool | Description |
|------|-------------|
| Mem Viewer | Browse physical RAM in hex, navigate with `+/-0x100` |
| Port I/O | Read (`IN`) / write (`OUT`) to any hardware port |
| VFS Inspector | View all VFS nodes: index, type, size, parent, name |
| CPU Registers | Capture EAX/EBX/ECX/EDX/CR0/CR3 live |
| IRQ Monitor | Monitor all 16 IRQ channels |
| Stack View | Dump current stack (ESP + 10 rows) |
| Kernel Log | Boot messages and subsystem init log |
| BSOD Tester | Simulate BSOD codes in a window (no real crash) |
| RTC Inspector | Raw CMOS register readout, live clock |
| Panic Sim | Custom kernel panic message simulator |

---

## LightSurf Browser

LightSurf supports local VFS pages and real internet (with RTL8139 NIC).

### URL Types

| URL | Description |
|-----|-------------|
| `about:home` | Browser home page |
| `about:lightos` | OS information |
| `about:system` | Live system stats |
| `about:bookmarks` | Your saved bookmarks |
| `about:help` | Markup reference |
| `file://Users/Default/readme.txt` | VFS file |
| `http://example.com` | Real website (needs network) |

### Toolbar

| Button | Action |
|--------|--------|
| `<` | Go back |
| `>` | Go forward |
| `R` | Reload page |
| `H` | Go home |
| `*` | Add/view bookmarks |
| URL bar | Click to edit, Enter to navigate |
| `Go` | Navigate to URL |

### Page Markup (built-in pages)

```
#Title           → Big heading with underline
---              → Horizontal divider
>Blockquote      → Blue-bar quote
- List item      → Bullet point
**bold text**    → Bold style
[link:url]text[/link]  → Clickable link
```

### Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+F` | Search in page |
| `Ctrl+D` | Bookmark current page |
| `ESC` | Close search / cancel URL edit |
| `↑` / `↓` | Scroll page |

---

## Network Support

LightOS includes a full network stack:

```
RTL8139 → Ethernet → ARP → IP → UDP/TCP → DHCP/DNS/HTTP
```

### Setup (QEMU)

```bash
-device rtl8139,netdev=n0 -netdev user,id=n0
```

On boot, LightOS automatically:
1. Detects RTL8139 via PCI scan
2. Sends DHCP DISCOVER
3. Gets IP/gateway/DNS from QEMU's built-in DHCP

### Browsing the Internet

Navigate to `http://example.com` in LightSurf.

> HTTPS is not supported (no TLS stack). Use HTTP only.

---

## Themes & Wallpapers

### Themes (Settings → Theme)

**Luna Steel** (default)
- Dark navy blue title bars
- Green start button
- Classic Windows-inspired look

**ColdIceBar**
- Frosted glass title bars
- Ice blue color palette
- Single shine line effect

### Wallpapers (Settings → Wallpaper)

**Luna Night** (default) — Dark blue with moon ring and stars  
**Dawn** — Purple → orange → gold sunrise with sun disk  
**Forest** — Dark green with tree silhouettes and moon  

Title bar colors automatically adapt to the selected wallpaper.

---

## Architecture

```
boot.asm          Multiboot1 entry, GDT, SSE init
kernel/init.c     PIC, framebuffer, subsystem init → start_shell()
shell.cpp         Main GUI loop, event handling, compositing
compositor.h      Z-order window stack, Gaussian shadow
gui.h             Window class (drag, resize, maximize, crash state)
graphics.h        PutPixel, DrawRect, DrawGradient, DrawString
font.h            8×8 bitmap font (ASCII + Turkish chars)
theme.h           Luna Steel / ColdIceBar color palettes
wallpaper.h       3 wallpapers + per-wallpaper title bar accents
lang.h            EN/TR string table
bsod.h            Blue Screen of Death renderer
startup.h         Boot animation + Developer Mode F4×5 trigger

kernel/
  vfs.h           RAM-based VFS (128 nodes, 4KB/file)
  acpi.h          RSDP→FADT→PM1 shutdown/restart
  clock.h         CMOS RTC reader
  sound.h         AC97 + PC Speaker audio driver
  hal.h           Hardware Abstraction Layer (port I/O)
  net/
    net.h         Ethernet/ARP/IP/TCP types
    rtl8139.h     RTL8139 NIC driver (PCI)
    tcp.h         TCP client stack
    dhcp.h        DHCP client
    http.h        HTTP GET + DNS resolver

drivers/
  io.h            8/16/32-bit port I/O
  serial.h        UART 16550A serial port driver
  keyboard/       PS/2 keyboard (TR-Q / EN-US layouts)
  mouse/          PS/2 mouse (3-byte packets, overflow protection)

apps/
  notepad         VFS text editor
  calculator      Basic arithmetic
  filemgr         VFS file browser
  settings        Keyboard/Theme/Wallpaper settings
  terminal        CLI with 11 commands
  paint           Pixel art tool
  sysinfo         Live system info
  clock_app       Analog+digital clock
  browser.h       LightSurf browser
  devtools.h      10 developer tools
```

---

## File System

LightOS uses an in-memory VFS (Virtual File System). Data resets on reboot.

### Default Structure

```
C:/
├── System/          (hidden unless Dev Mode)
│   ├── boot.cfg
│   └── kernel.bin
├── Users/
│   └── Default/
│       ├── readme.txt
│       └── notes.txt
├── Apps/
│   ├── notepad.app
│   └── calc.app
└── Temp/
    └── tmp0.tmp
```

### Limits

| Property | Value |
|----------|-------|
| Max nodes | 128 |
| Max file size | 4 KB |
| Max children per dir | 16 |
| Total data pool | 512 KB |

---

## Contributing

LightOS is open source. Pull requests welcome!

### What would be awesome to add

- [ ] IDE/ATA disk driver (persistent storage!)
- [ ] ext2 filesystem
- [ ] HTTPS / TLS
- [ ] PCnet NIC driver (VirtualBox native)
- [ ] More browser HTML support (tables, images)
- [ ] Audio player (WAV files)
- [ ] USB HID keyboard/mouse
- [ ] SMP (multi-core support)

### Building a new app

1. Create `apps/myapp.h` — extend `Window` class
2. Override `DrawContent()` and `OnClickContent()`
3. Add instance + `comp.Add()` in `shell.cpp`
4. Add icon + `S_MYAPP` string in `lang.h`
5. Add to QuickMenu and desktop icons

---

## Credits

**Author:** Xaef BTL  
**Year:** 2026  
**License:** MIT  

> Built with love, blood, and way too many triple faults. 🖥️
